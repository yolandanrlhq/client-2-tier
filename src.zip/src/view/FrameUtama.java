package view;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import model.MenuItem;
import net.miginfocom.swing.MigLayout;

// Import semua panel konten
import view.konten.*;
import view.menu.PanelMenu;

public class FrameUtama extends JFrame {

    private CardLayout cardLayout;
    private JPanel panelKonten;
    private PanelMenu panelMenu;

    // Referensi panel
    private PanelDashboard pDashboard;
    private PanelProduk pProduk;
    private PanelPesanan pPesanan;
    private PanelPelanggan pPelanggan;

    public FrameUtama() {
        initializeUI();
        setupPanelKonten();
        setupPanelMenu();
        addComponents();
    }

    private void initializeUI() {
        setTitle("Sistem Penyewaan Kostum Karakter - 2 Tier");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // 👉 JANGAN kunci ukuran terlalu besar
        setPreferredSize(new Dimension(1280, 720));

        // 👉 Minimum aman (supaya tetap bisa dikecilin)
        setMinimumSize(new Dimension(700, 450));

        // 👉 Layout utama RESPONSIVE (TANPA tanda seru)
        setLayout(new MigLayout(
                "fill, insets 0, gap 0",
                "[min:200:280][grow]",
                "[grow]"
        ));
    }

    private void setupPanelKonten() {
        cardLayout = new CardLayout();
        panelKonten = new JPanel(cardLayout);
        panelKonten.setBackground(Color.WHITE);

        pDashboard = new PanelDashboard();
        pProduk = new PanelProduk();
        pPesanan = new PanelPesanan();
        pPelanggan = new PanelPelanggan();

        panelKonten.add(pDashboard, "dashboard");

        panelKonten.add(pProduk, "produk");
        panelKonten.add(new PanelAddProduk(), "add_produk");

        panelKonten.add(pPesanan, "pesanan");
        panelKonten.add(new PanelAddPesanan(), "add_pesanan");

        panelKonten.add(pPelanggan, "pelanggan");
        panelKonten.add(new PanelAddPelanggan(), "add_pelanggan");
    }

    private void setupPanelMenu() {
        List<MenuItem> listMenu = new ArrayList<>();

        listMenu.add(new MenuItem("Dashboard", "dashboard"));

        MenuItem menuProduk = new MenuItem("Produk");
        menuProduk.addSubMenuItem(new MenuItem("Daftar Kostum", "produk"));
        menuProduk.addSubMenuItem(new MenuItem("Tambah Kostum", "add_produk"));
        listMenu.add(menuProduk);

        MenuItem menuPesanan = new MenuItem("Pesanan");
        menuPesanan.addSubMenuItem(new MenuItem("Data Pesanan", "pesanan"));
        menuPesanan.addSubMenuItem(new MenuItem("Tambah Pesanan", "add_pesanan"));
        listMenu.add(menuPesanan);

        MenuItem menuPelanggan = new MenuItem("Pelanggan");
        menuPelanggan.addSubMenuItem(new MenuItem("Daftar Pelanggan", "pelanggan"));
        menuPelanggan.addSubMenuItem(new MenuItem("Tambah Pelanggan", "add_pelanggan"));
        listMenu.add(menuPelanggan);

        panelMenu = new PanelMenu(listMenu, cardLayout, panelKonten);
    }

    private void addComponents() {
        add(panelMenu, "growy");
        add(panelKonten, "grow");
    }

    // ================= REFRESH PANEL =================

    public void gantiPanel(String key) {
        cardLayout.show(panelKonten, key);

        switch (key) {
            case "dashboard" -> pDashboard.refreshData();
            case "produk" -> pProduk.loadData();
            case "pesanan" -> pPesanan.loadData();
            case "pelanggan" -> pPelanggan.loadData();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                com.formdev.flatlaf.FlatLightLaf.setup();
            } catch (Exception e) {
                System.out.println("Gagal memuat tema.");
            }

            FrameUtama frame = new FrameUtama();
            frame.pack();                    // 🔑 pack dulu
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
